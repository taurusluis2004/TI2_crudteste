package service;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import dao.Alergiadao;
import dao.Alimentodao;
//import alimentodao.AlimentoAlimentoalimentodao;
import model.Alimento;
import spark.Request;
import spark.Response;


public class AlimentoService {
	
	
	//static Alimentoalimentodao alimentodao = new Alimentoalimentodao();


	//private AlimentoAlimentoalimentodao alimentoAlimentoalimentodao;
	private Alimentodao alimentodao;
	private Alergiadao alergiadao;

	public AlimentoService() {
		try {
			//alimentoAlimentoalimentodao = new AlimentoAlimentoalimentodao("alimento.dat");
			alimentodao=new Alimentodao();
			
			
			alimentodao.conectar();
			alimentodao.iniciar();
			alergiadao=new Alergiadao();
			alergiadao.conectar();
			alergiadao.iniciar();
			int idteste=alimentodao.maxid()+2;
			System.out.println(idteste+"aaab");
		} catch (Exception  e) {
			System.out.println(e.getMessage());
		}
	}

	public Object add(Request request, Response response) {
		System.out.println("elizeta");
		String nome = request.queryParams("nome");
		int  proteinas = Integer.parseInt(request.queryParams("proteina"));
		int calorias = Integer.parseInt(request.queryParams("calorias"));
		String alergia  = request.queryParams("alergias");
		
		
		//int usuario_id = Integer.parseInt(request.queryParams("usuario_id"));

		//int id = alimentoAlimentoalimentodao.getMaxId() + 1;
int id=alimentodao.maxid()+1;
System.out.println(id+"aaa");

		Alimento alimento = new Alimento(id, nome, proteinas, calorias,100);

		//alimentoAlimentoalimentodao.add(alimento);
alimentodao.inserirAlimento(alimento);
		response.status(201); // 201 Created
		return id;
	}

	public Object get(Request request, Response response) {
		int id = Integer.parseInt(request.params(":id"));
		
		//Alimento alimento = (Alimento) alimentoAlimentoalimentodao.get(id);
		Alimento alimento = (Alimento) alimentodao.get(id);
	
		
		if (alimento != null) {
    	    response.header("Content-Type", "application/xml");
    	    response.header("Content-Encoding", "UTF-8");

            return "<alimento>\n" + 
            		"\t<id>" + alimento.getId() + "</id>\n" +
            		"\t<nome>" + alimento.getNome() + "</nome>\n" +
            		"\t<proteinas>" + alimento.getProteinas() + "</proteinas>\n" +
            		"\t<calorias>" + alimento.getCalorias() + "</calorias>\n" +
            		//"\t<fabricacao>" + alimento.getUsuario_id() + "</fabricacao>\n" +
            		//"\t<validade>" + alimento.getDataValidade() + "</validade>\n" +
            		"</alimento>\n";
        } else {
            response.status(404); // 404 Not found
            return "Alimento " + id + " não encontrado.";
        }

	}

	public Object update(Request request, Response response) {
        int id = Integer.parseInt(request.params(":id"));
        
		Alimento alimento = (Alimento) alimentodao.get(id);

        if (alimento != null) {
        	alimento.setNome(request.queryParams("nome"));
        	alimento.setProteinas(Integer.parseInt(request.queryParams("proteinas")));
        	alimento.setCalorias(Integer.parseInt(request.queryParams("calorias")));
        	alimento.setUsuario_id(Integer.parseInt(request.queryParams("usuario_id")));
        	//alimento.setDataValidade(LocalDate.parse(request.queryParams("dataValidade")));

        	alimentodao.atualizarAlimento(alimento);
        	
            return id;
        } else {
            response.status(404); // 404 Not found
            return "Alimento não encontrado.";
        }

	}

	public Object remove(Request request, Response response) {
        int id = Integer.parseInt(request.params(":id"));

        Alimento alimento = (Alimento) alimentodao.get(id);

        if (alimento != null) {

            alimentodao.excluirAlimento(alimento);

            response.status(200); // success
        	return id;
        } else {
            response.status(404); // 404 Not found
            return "Alimento não encontrado.";
        }
	}
	

	public Object getAll(Request request, Response response) {
		StringBuffer returnValue = new StringBuffer("<alimentos type=\"array\">");
		for (Alimento alimento : alimentodao.getAlimentos()) {
			returnValue.append("\n<alimento>\n" + 
            		"\t<id>" + alimento.getId() + "</id>\n" +
            		"\t<nome>" + alimento.getNome() + "</nome>\n" +
            		"\t<proteinas>" + alimento.getProteinas() + "</proteinas>\n" +
            		"\t<calorias>" + alimento.getCalorias() + "</calorias>\n" +
            		//"\t<fabricacao>" + alimento.getUsuario_id() + "</fabricacao>\n" +
            		//"\t<validade>" + alimento.getDataValidade() + "</validade>\n" +
            		"</alimento>\n");
		}
		returnValue.append("</alimentos>");
	    response.header("Content-Type", "application/xml");
	    response.header("Content-Encoding", "UTF-8");
		return returnValue.toString();
	}
}
