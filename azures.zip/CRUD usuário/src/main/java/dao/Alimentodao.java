package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import model.Alergia;
import model.Alimento;
//import dao.AlimentoAlimentodao;

public class Alimentodao {
public int maxid;
	private Connection conexao;
	private List<Alimento> alimentosPostgre;
	
	public Alimentodao() {
		conexao = null;
	maxid=-1;
		
	}


	public boolean conectar() {
		String driverName = "org.postgresql.Driver";                    
		String serverName = "localhost";
		String mydatabase = "postgres";
		int porta = 5432;
		String url = "jdbc:postgresql://" + serverName + ":" + porta +"/" + mydatabase;
		String username = "postgres";
		String password = "123";
		boolean status = false;

		try {
			Class.forName(driverName);
			conexao = DriverManager.getConnection(url, username, password);
			status = (conexao == null);
			System.out.println("Conexão efetuada com o postgres!");
			
		
			
		} catch (ClassNotFoundException e) { 
			System.err.println("Conexão NÃO efetuada com o postgres -- Driver não encontrado -- " + e.getMessage());
		} catch (SQLException e) {
			System.err.println("Conexão NÃO efetuada com o postgres -- " + e.getMessage());
		}

		return status;
	}
	
	public boolean close() {
		boolean status = false;
		
		try {
			conexao.close();
			status = true;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return status;
	}

	public int maxid(){
		int maxid=-1;
	try {
		System.out.println("try executado");
		alimentosPostgre.get(0).getId();
		for (Alimento alimento : alimentosPostgre) {
			System.out.println(alimento.getId()+"alimento");
			if (alimento.getId()>maxid) {
maxid=alimento.getId();
System.out.println(alimento.getId()+"idalimento");
				
			}

			}
		System.out.println("maxima de "+maxid);
		
	}catch (Exception e) {
		System.err.println(e.getMessage());
	}
	 return maxid;
	}

	
	public boolean inserirAlimento(Alimento alimento) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			st.executeUpdate("INSERT INTO alimentos (id, nome_alimento, proteinas, calorias) "
					       + "VALUES ("+alimento.getId()+ ", '" + alimento.getNome() + "', "  
					       + alimento.getProteinas() + ", " + alimento.getCalorias() + " );");
			
			st.close();
		alimentosPostgre.add(alimento);
			
			status = true;
		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public boolean atualizarAlimento(Alimento alimento) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			String sql = "UPDATE alimento SET nome_alimento = '" + alimento.getNome() + "', proteinas = '"  
				       + alimento.getProteinas() + "', calorias = '" + alimento.getCalorias() + "'"
					   + " WHERE id = " + alimento.getId();
			st.executeUpdate(sql);
			st.close();
			status = true;
			
				int index = alimentosPostgre.indexOf(alimento);
				if (index != -1) {
					alimentosPostgre.set(index, alimento);
				
				}
			

		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public boolean excluirAlimento(Alimento alimento) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			st.executeUpdate("DELETE FROM alimento WHERE id = " + alimento.getId());
			st.close();
			status = true;
			int index = alimentosPostgre.indexOf(alimento);
		
				alimentosPostgre.remove(index);
			
			
		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public Alimento get(int id) {
		System.out.println(alimentosPostgre.get(0).getId());
		System.out.println(id);
		for (Alimento alimento : alimentosPostgre) {
			System.out.println(alimento.getId());
			if (id == alimento.getId()) {

				return alimento;
			}
		}
		return null;
	}
	public int pesquisar(String nomealimento) {
	
	if(nomealimento!=null) {
		for (Alimento alimento : alimentosPostgre) {
			
			if (nomealimento.compareTo(alimento.getNome())==0) {

				return alimento.getId();
			
		}
		}
	}
		return -1;
	}
	
	public void iniciar() {
		
		try {
			System.out.println("LLL");
			alimentosPostgre = new ArrayList<Alimento>();
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = st.executeQuery("SELECT * FROM alimentos");		
	         if(rs.next()){
	             rs.last();
	          
	             rs.beforeFirst();

	             for(int i = 0; rs.next(); i++) {
	            	
	            		System.out.println("LLL");
	            	 
	                Alimento alimento = new Alimento(rs.getInt("id"), rs.getString("nome_alimento"), 
	                		                  rs.getInt("proteinas"), rs.getInt("calorias"),rs.getInt("usuario_id"));
	                System.out.println(alimento.getId());
	                alimentosPostgre.add(alimento);
	                System.out.println(alimentosPostgre.get(i).getNome()+"a");
	                
	             }
	             
	             
	          }
	          st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		
	}
	public Alimento[] getAlimentos() {
		Alimento[] alimentos = null;
		
		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = st.executeQuery("SELECT * FROM alimentos");		
	         if(rs.next()){
	             rs.last();
	             alimentos = new Alimento[rs.getRow()];
	             rs.beforeFirst();

	             for(int i = 0; rs.next(); i++) {
	            	
	            	 
	            	 System.out.println("ograsso");
	                alimentos[i] = new Alimento(rs.getInt("id"), rs.getString("nome_alimento"), 
	                		                  rs.getInt("proteinas"), rs.getInt("calorias"), rs.getInt("usuario_id"));
	                
	             }
	             
	             
	          }
	          st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return alimentos;
	}
 

}
