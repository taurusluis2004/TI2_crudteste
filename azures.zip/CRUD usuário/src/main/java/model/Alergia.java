package model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Alergia implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String DESCRICAO_PADRAO = "Novo alergia";
	
	private int id;

	
	private int usuario_id;
	private String nome;
	private int alimento_id;

	
	public Alergia() {
		id = -1;
		usuario_id=-1;
		alimento_id=-1;
	
	
	}

	public Alergia(int id,String nome,int usuario__id, int alimento_id) {
		setId(id);
		
		setAlimento_id(alimento_id);
		setNome(nome);
		setUsuario_id(usuario_id);
		
	}		
	
	public int getId() {
		return id;
	}
	

	public void setId(int id) {
		this.id = id;
	}
	public int getUsuario_id() {
		return this.usuario_id;
	}
	
	public void setUsuario_id(int usuario_id) {
		this.usuario_id = usuario_id;
	}
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

	


	public int getAlimento_id() {
		return this.alimento_id;
	}

	public void setAlimento_id(int id_alimento) {

			this.alimento_id = alimento_id;
	}


	
	
	

	

	





	/**
	 * Método sobreposto da classe Object. É executado quando um objeto precisa
	 * ser exibido na forma de String.
	 */
	//@Override
	/*public String toString() {
		return "Produto: " + descricao + "   Preço: R$" + proteinas + "   Quant.: " + calorias ;
	}
	*/
	
	@Override
	public boolean equals(Object obj) {
		return (this.getId() == ((Alergia) obj).getId());
	}	
}