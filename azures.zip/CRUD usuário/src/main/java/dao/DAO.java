package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import model.Usuario;


public class DAO {
public int maxid;
	private Connection conexao;
	private List<Usuario> usuariosPostgre;
	
	public DAO() {
		conexao = null;
	maxid=-1;
		
	}


	public boolean conectar() {
		String driverName = "org.postgresql.Driver";                    
		String serverName = "localhost";
		String mydatabase = "postgres";
		int porta = 5432;
		String url = "jdbc:postgresql://" + serverName + ":" + porta +"/" + mydatabase;
		String username = "postgres";
		String password = "123";
		boolean status = false;

		try {
			Class.forName(driverName);
			conexao = DriverManager.getConnection(url, username, password);
			status = (conexao == null);
			System.out.println("Conexão efetuada com o postgres!");
			
		
			
		} catch (ClassNotFoundException e) { 
			System.err.println("Conexão NÃO efetuada com o postgres -- Driver não encontrado -- " + e.getMessage());
		} catch (SQLException e) {
			System.err.println("Conexão NÃO efetuada com o postgres -- " + e.getMessage());
		}

		return status;
	}
	
	public boolean close() {
		boolean status = false;
		
		try {
			conexao.close();
			status = true;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return status;
	}

	public int maxid(){
		int maxid=-1;
	try {
		
		for (Usuario usuario : usuariosPostgre) {
			System.out.println(usuario.getId());
			if (usuario.getId()>maxid) {
maxid=usuario.getId();
				
			}

		}
		System.out.println("maxima de "+maxid);}catch (Exception e) {
		System.err.println(e.getMessage());
	}
	 return maxid;
	}
	
	public boolean inserirUsuario(Usuario usuario) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			st.executeUpdate("INSERT INTO usuarios (id, nome, peso, altura,senha,email) "
					       + "VALUES ("+usuario.getId()+ ", '" + usuario.getNome() + "', "  
					       + usuario.getPeso() + ", " + usuario.getAlt() + ", '" +usuario.getSenha()+"','" +usuario.getEmail()+"');");
			st.close();
		usuariosPostgre.add(usuario);
			
			status = true;
		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public boolean atualizarUsuario(Usuario usuario) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			String sql = "UPDATE usuario SET nome = '"
					+ "" + usuario.getNome() + "', peso = '"  
		               + usuario.getPeso() + "', altura = '" + usuario.getAlt() + "', "
		               + "email = '" + usuario.getEmail() + "', senha = '" + usuario.getSenha() + "'"
		               + " WHERE id = " + usuario.getId();
			st.executeUpdate(sql);
			st.close();
			status = true;
			
				int index = usuariosPostgre.indexOf(usuario);
				if (index != -1) {
					usuariosPostgre.set(index, usuario);
				
				}
			

		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public boolean excluirUsuario(Usuario usuario) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			st.executeUpdate("DELETE FROM usuarios WHERE id = " + usuario.getId());
			st.close();
			status = true;
			int index = usuariosPostgre.indexOf(usuario);
		
				usuariosPostgre.remove(index);
			
			
		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public Usuario get(int id) {
		System.out.println(usuariosPostgre.get(0).getId());
		System.out.println(id);
		for (Usuario usuario : usuariosPostgre) {
			System.out.println(usuario.getId());
			if (id == usuario.getId()) {

				return usuario;
			}
		}
		return null;
	}
	
	public Usuario pesquisar_nome(String nome) {
		
		
		for (Usuario usuario : usuariosPostgre) {
			System.out.println("ativou funcao");
			if (nome.compareTo(usuario.getNome()) == 0) {
System.out.println("usuario encontrado" +usuario.getNome());
				return usuario;
			}
		}
		return null;
	}
	public void iniciar() {
		
		try {
			usuariosPostgre = new ArrayList<Usuario>();
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = st.executeQuery("SELECT * FROM usuarios");		
	         if(rs.next()){
	             rs.last();
	          
	             rs.beforeFirst();

	             for(int i = 0; rs.next(); i++) {
	            	
	            	 
	            	 
	                Usuario usuario = new Usuario(rs.getInt("id"), rs.getString("nome"), 
	                		                  rs.getInt("peso"), rs.getInt("altura"), rs.getString("senha"),rs.getString("email"));
	                System.out.println(usuario.getId());
	                usuariosPostgre.add(usuario);
	                
	             }
	             
	             
	          }
	          st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		
	}
	public Usuario[] getUsuarios() {
		Usuario[] usuarios = null;
		
		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = st.executeQuery("SELECT * FROM usuarios");		
	         if(rs.next()){
	             rs.last();
	             usuarios = new Usuario[rs.getRow()];
	             rs.beforeFirst();

	             for(int i = 0; rs.next(); i++) {
	            	
	            	 
	            	 
	                usuarios[i] = new Usuario(rs.getInt("id"), rs.getString("nome"), 
	                		                  rs.getInt("peso"), rs.getInt("altura"), rs.getString("senha"),rs.getString("email"));
	                
	             }
	             
	             
	          }
	          st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return usuarios;
	}
 

}
