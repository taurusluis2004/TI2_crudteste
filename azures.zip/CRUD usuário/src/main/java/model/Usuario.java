package model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String DESCRICAO_PADRAO = "Novo Produto";
	public static final int MAX_ESTOQUE = 1000;
	private int id;
	private String nome;
	private float peso;
	private int altura;
	private LocalDateTime dataFabricacao;	
	private LocalDate dataValidade;
	private String senha;
	private float IMC;
	private String email;
	public Usuario() {
		id = -1;
		nome = DESCRICAO_PADRAO;
		peso = 0.01F;
		altura = 0;
		senha=DESCRICAO_PADRAO;
		dataFabricacao = LocalDateTime.now();
		dataValidade = LocalDate.now().plusMonths(6); // o default é uma validade de 6 meses.
		IMC=0;
	}

	public Usuario(int id, String nome, float peso, int altura, String senha,String email) {
		setId(id);
		setNome(nome);
		setPeso(peso);
		setAlt(altura);
		setSenha(senha);
		setEmail(email);
	
		setIMC(altura,peso);
		
		
	}
	
	
	public int getId() {
		return id;
	}
	


	public void setId(int id) {
		this.id = id;
	}
	
	public int getEmail() {
		return id;
	}
	
	
	public void setEmail(String email) {
		this.email=email;
	}
	

	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		if (nome.length() >= 3)
			this.nome = nome;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		if (peso > 0)
			this.peso = peso;
	}

	public int getAlt() {
		return altura;
	}
	
	public void setAlt(int altura) {
		if (altura >= 0 && altura <= MAX_ESTOQUE)
			this.altura = altura;
	}
	
	public LocalDate getDataValidade() {
		return dataValidade;
	}

	public String  getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
			this.senha = senha;
	}
	public float  getIMC() {
		return IMC;
	}

	public void setIMC(int altura,float peso) {
		float  IMC=peso/(altura*altura);
		this.IMC = IMC;
	}	

	public void setDataValidade(LocalDate dataValidade) {
		// a data de fabricação deve ser anterior é data de validade.
	
			this.dataValidade = dataValidade;
	}

	public boolean emValidade() {
		return LocalDateTime.now().isBefore(this.getDataValidade().atTime(23, 59));
	}

	/**
	 * Método sobreposto da classe Object. É executado quando um objeto precisa
	 * ser exibido na forma de String.
	 */
	@Override
	public String toString() {
		return "Produto: " + nome + "   Preço: R$" + peso + "   Alt.: " + altura + "   Fabricação: "
				+ dataFabricacao  + "   Data de Validade: " + dataValidade;
	}
	
	@Override
	public boolean equals(Object obj) {
		return (this.getId() == ((Usuario) obj).getId());
	}


}